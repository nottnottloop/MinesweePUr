# MinesweePUr

![MinesweePUr](images/medium50.png)

MinesweePUr is a Minesweeper clone coded in C++ and SDL2.

Quite happy with this until the end where the code turns into spaghetti ;)

The PU originally was going to stand for powerups. Didn't really think powerups would be fun in the end. I might add a 'crazy mode' where the board moves erratically in the future.

![MinesweePUr](images/expert.png)